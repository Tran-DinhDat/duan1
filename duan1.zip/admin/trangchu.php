<div class="alert alert-danger">
	<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
	<strong>Cảnh báo</strong> Đăng nhập hệ thống quản trị!
</div>