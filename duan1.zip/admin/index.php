<?php 
require_once "../global.php";
require_once "../pdo.php";
require_once "../dao/kvt.php";
require_once'../dao/khach_hang.php';
check_login_admin();
$VIEW_NAME = "trangchu.php";
require 'layout.php';
?>