<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<div class="row">
<div class="col-md-12 gioi-thieu" style="">
	<h3 class="alert alert-info tieu-de-top">Giới thiệu về Trang Website Asiatravel.com</h3>
	<p class="text-justify" >
Trang http://www.Asiatravel.com là website của Công ty TNHH Dịch vụ và Du lịch VIETSENSE. Đây là một trong những trang web của Công ty Du lịch hàng đầu tại Việt Nam. Với đội ngũ nhân viên năng động, sáng tạo, chuyên ngiệp, sẵn sàng trả lời và tư vấn cho du khách mọi thông tin về Du lịch cũng như du lịch Singapore sẽ giúp quý khách hàng có những lựa chọn thông minh nhất.Truy cập trang web này Du khách sẽ hiểu hơn về du lịch, đặc biệt là Du lịch Singapore bởi thông tin được update hàng giờ, hàng ngày luôn mới lạ và nóng bỏng về mọi vấn đề xoay quanh Singapore</p>
<img src="../css/images/1.jpg" style="height: 250px" width="100%" >
<p class="text-justify">Website Asiatravel.com là trang có nhiều thông tin về Du lịch như: Du lịch Singapore, tin tức Singapore, ẩm thực Singapore… đặc biệt là các tour chuyên tuyến Miền Tây. Với đội ngũ nhân viên website năng động, nhiệt tình, giàu kinh nghiệm sẽ sẵn sàng giúp đỡ Du khách trong mọi tình huống tìm hiểu về tour tuyến Singapore. Chúng tôi tin rằng với chất lượng và dịch vụ phục vụ tốt nhất sẽ làm cho quý khách thực sự có những kì nghỉ Singapo thú vị và hấp dẫn.

Từ website Asiatravel.com chúng tôi đã phủ sóng rộng khắp thông tin về mạng lưới các tour, tuyến du lịch Miền Tây cho mọi bạn bè trong và ngoài nước biết tới, điều này đảm bảo chất lượng dịch vụ, cũng như giá cả luôn luôn hợp lí nhất cho mọi khách hàng. Hiện nay chúng tôi đang xây dựng và nâng cấp giao diện cũng như nội dung trang Asiatravel.com hoàn toàn mới. Trong tương lai, chúng tôi sẽ tiếp tục hoàn thiện hơn nữa để củng cố vị thế của mình cùng Website các tour Du lịch Singapore cho mọi Du khách trong và ngoài nước cùng biết tới.

Hãy liên hệ  ngay với chúng tôi khi có nhu cầu về tham quan du lịch, Vietsense Travel luôn sẵn sàng phục vụ Du khách!</p>
<img src="../css/images/4.jpg" style="height: 250px" width="100%" >
<p class="text-justify"> 
	+ Du Lịch Singapore - Sentosa 4 Ngày 3 Đêm: Singapore là một thành phố phát triển với sự pha trộn giữa ảnh hưởng của người Trung Quốc, người Malaysia và người Ấn Độ. Thêm vào đó là khí hậu nhiệt đới, thức ăn ngon, nơi mua sắm lý tưởng và cuộc sống về đêm đầy sôi động, thành phố vườn này là một điểm dừng chân tuyệt vời trong khu vực.<br>

+ Tour Du Lịch Singapore Mừng Lễ Mùng 2.9 Khởi Hành Từ Hà Nội: Du lịch Singapore 4 Ngày Khởi Hành Ngày 29/8/2015 sẽ đưa Qúy khách đến với đảo quốc nhỏ bé hiện đại , năng động với sự pha trộn hài hòa về văn hóa , ẩm thực, nghệ thuật và kiến trúc của phương Đông và phương Tây. Đặc biệt khi đến đấy, Quý khách sẽ được chiêm ngưỡng một đất nước được mệnh danh là xanh - sạch - đẹp nhất thế giới… <br>

+ Khám Phá tour Du lịch Quốc Đảo Singapore 4 Ngày 3 Đêm: Du lịch Singapore 4 Ngày Khởi Hành Ngày 15/8/2015 sẽ đưa Qúy khách đến với đảo quốc nhỏ bé hiện đại , năng động với sự pha trộn hài hòa về văn hóa , ẩm thực, nghệ thuật và kiến trúc của phương Đông và phương Tây. Đặc biệt khi đến đấy, Quý khách sẽ được chiêm ngưỡng một đất nước được mệnh danh là xanh - sạch - đẹp nhất thế giới.<br>

+ Du Lịch Singapore - Tự Do shopping: Du lịch Singapore 4 Ngày Khởi Hành Ngày 15/08/2015 sẽ đưa Qúy khách đến với đảo quốc nhỏ bé hiện đại , năng động với sự pha trộn hài hòa về văn hóa , ẩm thực, nghệ thuật và kiến trúc của phương Đông và phương Tây. Đặc biệt khi đến đấy, Quý khách sẽ được chiêm ngưỡng một đất nước được mệnh danh là xanh - sạch - đẹp nhất thế giới.
</p>
<img src="../css/images/4.jpg" style="height: 250px" width="100%" >

<p class="text-justify">
	+ Tour Du Lịch Malaysia - Singapore 7 Ngày 6 Đêm: Hà Nội - Malaysia – Singapore: Du Lịch Malaysia – Singapore, một hành trình tour- Tham quan hai nước. Malaysia và Singapore có thể xem như hai nước anh em và đều là những quốc gia có nền văn hóa đa dạng, nhiều màu sắc. Đều là những quốc gia phát triển trong khu vực, cả hai quốc gia đều thu hút rất nhiều các du khách từ khắp nơi trên thế giới tới tham quan. Quý khách còn có thể cảm nhận một đất nước trật tự, kinh tế phát triển, giao thông thuận tiện, con người vô cùng thân thiện.<br>

+ Du Lịch Malaysia: Malacca – Cameron – Kuala Lumpur (4N/3D): Không khí thơ mộng lơ đãng nơi đây với từng đám mây là đà gần mặt đất, những khu biệt thự đậm chất cổ kính Anh quốc, hay cánh rừng thần tiên được bao phủ bởi rêu xanh. Đặc biệt đến với Cameron bạn sẽ được thử cảm giác trở thành nông dân, vào vườn hái những quả dâu mọng đỏ, cùng chăm sóc các bồn hoa, cắt từng luống rau xanh về thưởng thức, Không những vậy, Cameron còn nổi tiếng với những nông trại bướm, ong, hoa hồng, hoa oải hương, và những đồi chè xanh ngát. Nếu bạn là người yêu thiên nhiên và thích khám phá những khu rừnghoang sơ thì Cameron là một sự lựa chọn tuyệt vời.<br>

+ Du Lịch Malaysia: Tp.hcm Malacca – Cameron – Kuala Lumpur(4N3D): Cao nguyên Cameron nằm phía tây bắc bang Pahang, Malaysia cách thủ đô Kuala Lumpur khoảng 200km, Cao nguyên Cameron sở hữu không khí trong lành và mát mẻ quanh năm.Không khí thơ mộng lơ đãng nơi đây với từng đám mây là đà gần mặt đất, những khu biệt thự đậm chất cổ kính Anh quốc, hay cánh rừng thần tiên được bao phủ bởi rêu xanh. Đặc biệt đến với Cameron bạn sẽ được thử cảm giác trở thành nông dân, vào vườn hái những quả dâu mọng đỏ, cùng chăm sóc các bồn hoa, cắt từng luống rau xanh về thưởng thức, Không những vậy, Cameron còn nổi tiếng với những nông trại bướm, ong, hoa hồng, hoa oải hương, và những đồi chè xanh ngát. Nếu bạn là người yêu thiên nhiên và thích khám phá những khu rừnghoang sơ thì Cameron là một sự lựa chọn tuyệt vời.<br>

+ Du Lịch Malaysia: Kuala Lumpur – Đảo Pangkor (5N/4Đ): Du Lịch Malaysia - “Không khí trong lành của Pangkor là món quà tuyệt vời dành cho du khách. Bất kể đến với Pangkor bằng cách nào và mất bao lâu, ngay phút đầu ngắm nhìn phong cảnh trên đảo và hít một hơi đầy lồng ngực, bạn sẽ cảm thấy khoẻ khoắn một cách bấy ngờ. Với một kẻ lười biếng chỉ muốn nằm ườn trên bãi biển như tôi, cảm giác khoẻ khoắn lạ thường đó đã thôi thúc tôi tham gia nhiều hoạt động để được hoà mình vào cuộc sống của Pangkor trọn vẹn hơn. Chắc hẳn không ai có thể dễ dàng quên được tiết mục câu cá ở biển, không cẩn thận là câu phải……nhánh san hô.<br>

+ Tour Du Lịch Malaysia 4 Ngày 3 Đêm: Hà Nội - Kuala Lumpur - Cao Nguyên Genting: Du Lịch Malaysia – Khám phá thành phố hành chính mới của Malaysia, cách Kuala Lumpur chỉ 25 km về phía Nam. Đây là mô hình kiểu mẫu của một thành phố hiện đại, duyên dáng với các công trình kiến trúc được phủ một màu xanh tươi mát, thanh bình…<br>
</P>

</div>

</div>
</body>
</html>