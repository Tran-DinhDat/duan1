<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<div class="row">
	<div class="col-md-12">
		<h3 class="alert alert-info tieu-de-top">Tận hưởng 23 ngày vàng - Ngập tràn ưu đãi cùng Vietravel</h3>
		<p class="text-justify">
Nhằm tri ân quý khách hàng đã đồng hành cùng Vietravel trong suốt thời gian qua, nhân dịp kỷ niệm 23 năm thành lập, Vietravel tung ra chương trình ưu đãi “23 Ngày Vàng - Ngập tràn ưu đãi” từ 28/11 –20/12/2018. Đây là hoạt động nằm trong chương trình khuyến mại Xuân 2019.</p>
<img src="https://media.vietravel.net/Images/NewsPicture/1-vietravel-23-ngay.jpg" style="width: 100%">
<p class="text-justify">
	<b>Nhân đôi mức giảm giá nhóm đến 1,6 triệu đồng/khách</b><br>
Vietravel sẽ nhân 2 mức giảm ở một số dòng tour và sẽ “bật mí” cho khách hàng ở thời điểm diễn ra chương trình. Khách được giảm giá nhóm sẽ được giảm giá đồng thời với ưu đãi thẻ thành viên, nâng tổng hạng mức giảm lên 7.9 triệu/khách.<br>

<b>Ưu đãi thẻ Thành viên Vietravel lên đến 1,5 triệu đồng/khách</b><br>
Có thể nói Vietravel là đơn vị lữ hành rất chú trọng đến công tác chăm sóc khách hàng. Công ty đã phát triển hệ thống thẻ thành viên từ rất sớm và luôn dành ưu đãi đặc biệt cho các khách hàng này.Du khách sở hữu thẻ thành viên Vietravel sẽ được giảm đến 1.5 triệu đồng (*)
</p>
<img src="https://media.vietravel.net/Images/NewsPicture/vietravel-23-ngay(1).jpg" style="width: 100%;>
<p class="text-justify">
	<b>
		Cơ hội trúng Đồng tiền vàng Vietravel phiên bản 23 năm trị giá 1 lượng vàng 9999</b><br>
Khi hoàn tất thanh toán từ 28/11 - hết 20/12, du khách sẽ có cơ hội trúng thưởng đồng tiền vàng Vietravel phiên bản 23 năm. Với số lượng 23 đồng tiền vàng trong 23 ngày diễn ra chương trình, Vietravel sẽ rút thăm mỗi ngày để tìm ra người may mắn trúng thưởng. Đây không phải là những đồng tiền Vàng thông thường mà còn chứa đựng nhiều điều “bí ẩn” sẽ được Công ty tiết lộ vào ngày kỷ niệm 23 năm thành lập (20/12/1995 – 20/12/2018). Khách hàng chắc chắn sẽ nhận được nhiều điều thú vị bất ngờ khi giá trị của phần thưởng không chỉ dừng lại ở mức 1 lượng vàng mà được gia tăng nhiều lần.

</p>
	
	</div>
</div>
</body>
</html>