<div class="container">
	<div id="myCarousel" class="carousel slide slide-main" data-ride="carousel">
  <!-- Indicators -->
  <ol class="carousel-indicators">
    <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
    <li data-target="#myCarousel" data-slide-to="1"></li>
    <li data-target="#myCarousel" data-slide-to="2"></li>
  </ol>

  <!-- Wrapper for slides -->
  <div class="carousel-inner">
    <div class="item active">
      <img src="../css/images/1.jpg" alt="Los Angeles">
     <!--  <div class="carousel-caption">
        <h1 class="text-info">TravelAce</h1>
        <button type="button" class="btn btn-dat-tour">Liên Hệ</button>
        <button type="button" class="btn btn-outline">Xem Nhiều Hơn</button>
      </div> -->
    </div>

    <div class="item">
      <img src="../css/images/2.jpg" alt="Chicago">
    </div>

    <div class="item">
      <img src="../css/images/3.jpg" alt="New York">
    </div>
  </div>

  <!-- Left and right controls -->
  <a class="left carousel-control" href="#myCarousel" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="right carousel-control" href="#myCarousel" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
<!-- <div class="search owl-carousel owl-theme">
  <?php //foreach ($kvt as $key => $value) : ?>
	<div style="margin: 0 5px;">
		<img src="../css/images/<?php// echo $value["hinh"] ?>" alt="Du lịch tự chọn" class="mg-b">
			<p class="text2 text-dltc" style="color: #fff; font-size: 17px;font-weight: bold;"><?//=$value['ten_kvt']?></p>
  </div>
  <?php// endforeach; ?>
	
</div>
<div class="form-group search2">
    <input type="text" class="form-control" placeholder="Search">
  </div>
</div> -->
