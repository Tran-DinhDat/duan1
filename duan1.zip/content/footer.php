<!-- <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script> -->
<!------ Include the above in your HEAD tag ---------->
<!-- <link rel="stylesheet" type="text/css" href="style.css"> -->
        <!--footer-->
<footer class="kilimanjaro_area">
        <!-- Top Footer Area Start -->
        <div class="foo_top_header_one section_padding_100_70">
            <div class="container">
                <div class="row">
                    <div class="col-12 col-md-6 col-lg-3">
                        <div class="kilimanjaro_part">
                            <h5>Giới Thiệu</h5>
                            <p> Quả đất: Là hình ảnh thế giới - thể hiện phạm vi hoạt động mang tính toàn cầu của Fiditour với những chuyến đi đó đây, đến khắp năm châu. Quả đất kết hợp với đường lượn tạo thành chữ Q còn mang nghĩa chất lượng (Quality),
</p>
                            
                        </div>
                        <div class="kilimanjaro_part m-top-15">
                            <h5>Xã Hội</h5>
                            <ul class="kilimanjaro_social_links">
                                <li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i> Facebook</a></li>
                                <li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i> Twitter</a></li>
                                <li><a href="#"><i class="fa fa-pinterest" aria-hidden="true"></i> Pinterest</a></li>
                                <li><a href="#"><i class="fa fa-youtube" aria-hidden="true"></i> YouTube</a></li>
                                <li><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i> Linkedin</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-12 col-md-6 col-lg-3">
                        <div class="kilimanjaro_part">
                            <h5>Thẻ Tiện Ích</h5>
                            <ul class=" kilimanjaro_widget">
                                <li><a href="#">Quảng Cáo</a></li>
                                <li><a href="#">Blog</a></li>
                                <li><a href="#">Liên Hệ</a></li>
                                <li><a href="#">Tư Vấn</a></li>
                                <li><a href="#">Đa Năng</a></li>
                                <li><a href="#">Dịch Vụ</a></li>
                                <li><a href="#">Tiện Ích</a></li>
                                <li><a href="#">Hỏi Đáp</a></li>
                            </ul>
                        </div>

                        <div class="kilimanjaro_part m-top-15">
                            <h5>Liên Kết Tour</h5>
                            <ul class="kilimanjaro_links">
                                <li><a href="#"><i class="fa fa-angle-right" aria-hidden="true"></i>Điều Khoảng & Điều Kiện</a></li>
                                <li><a href="#"><i class="fa fa-angle-right" aria-hidden="true"></i>Giới Thiệu Chi Tiết</a></li>
                                <li><a href="#"><i class="fa fa-angle-right" aria-hidden="true"></i>Hỗ Trợ</a></li>
                                <li><a href="#"><i class="fa fa-angle-right" aria-hidden="true"></i>Chính Sách Bảo mật</a></li>
                                <li><a href="#"><i class="fa fa-angle-right" aria-hidden="true"></i>Tourrist</a></li>
                                <li><a href="#"><i class="fa fa-angle-right" aria-hidden="true"></i>Cộng Đồng</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-12 col-md-6 col-lg-3">
                        <div class="kilimanjaro_part">
                            <h5>Tin Nỗi Bậc</h5>
                            <div class="kilimanjaro_blog_area">
                                <div class="kilimanjaro_thumb">
								<img class="img-fluid" src="http://st.galaxypub.vn/staticFile/Subject/2016/07/21/447629/title_21622347.jpg" alt="">

                                </div>
                                <a href="#">Cặp Đôi Trấn Thành & Hari </a>
                                <p class="kilimanjaro_date">21/06/ 2018</p>
                                <p>Tour Du lịch hấp dẫn vong quanh đất nươc</p>
                            </div>
                            <div class="kilimanjaro_blog_area">
                                <div class="kilimanjaro_thumb">
								<img class="img-fluid" src="https://toasoanso5.com/wp-content/uploads/2018/08/nha-phuong-bao-hoa-hau-doanh-nhan-1.jpg" alt="" >
                                </div>
                                <a href="#">Trương Giang & Nhã Phương</a>
                                <p class="kilimanjaro_date">02-08-2018</p>
                                <p>Tour Họ chọn là du lịch USA</p>
                            </div>
                            <div class="kilimanjaro_blog_area">
                                <div class="kilimanjaro_thumb">
								<img class="img-fluid" src="https://znews-photo.zadn.vn/w660/Uploaded/OpluOAA/2014_12_19/luongthethanh1.jpg" alt="">
                                </div>
                                <a href="#">Thúy Diễm & Lương Thế Thành</a>
                                <p class="kilimanjaro_date">02-01-2017</p>
                                <p>Tour Ninh Bình-Hạ Long</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-md-6 col-lg-3">
                        <div class="kilimanjaro_part">
                            <h5>Quick Contact</h5>
                            <div class="kilimanjaro_single_contact_info">
                                <h5>Liên Hệ:</h5>
                                <p>+255 789 54 50 40 <br> +2255 766 90 94 00</p>
                            </div>
                            <div class="kilimanjaro_single_contact_info">
                                <h5>Email:</h5>
                                <p>hoanguyenqtmc.com <br> datchodien@gmail.com</p>
                            </div>
                        </div>
                        <div class="kilimanjaro_part">
                            <h5>Latest Works</h5>
                            <div class="kilimanjaro_works">
                                <a class="kilimanjaro_works_img" href="img/gallery/1.jpg"><img src="http://images.ongbachau.vn/Images/Uploaded/Share/2014/11/17/10-noi-dao-bien-hap-dan-nhat-Viet-Nam-1.jpg"  width="100px" height="80px" alt=""></a>
                                   <a class="kilimanjaro_works_img" href="img/gallery/1.jpg"><img src="https://blog.vacbalo.com/wp-content/uploads/2017/10/dao-phu-quoc.jpgdao-phu-quoc.jpg" width="100px" height="80px" alt="" ></a>
                                      <a class="kilimanjaro_works_img" href="img/gallery/1.jpg"><img src="http://vietnamtourism.gov.vn/english/images/2015/HoatamgiacmachHG.jpg" width="100px" height="80px" alt=""></a>

                               
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Footer Bottom Area Start -->
        <div class=" kilimanjaro_bottom_header_one section_padding_50 text-center">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <p><img src="https://www.fiditour.com/content/images/dathongbao.png" width="200px" height="80px" /><br><a href="#">TƯ VẤN & ĐẶT DỊCH VỤ: 1900 1808<br>
                            Website ANDYTOURIST.NET đã được đăng ký với Bộ Công Thương<i class="fa fa-love"></i></a></p>
                    </div>
                </div>
            </div>
        </div>
    </footer>